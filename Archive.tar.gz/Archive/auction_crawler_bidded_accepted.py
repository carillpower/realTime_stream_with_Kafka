from time import time, sleep
from threading import Event
from utility import reload_page_if_timeout, get_last_page, scrap_listing

def bidded_rejected(browser, gcp_sa):
    start = time()
    # Click Rejected Tab
    reload_page_if_timeout(browser, 'xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[7]')
    browser.locator('xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[7]').click()
    sleep(10)
    print("Start Crawling biddded rejected")
    # Get last page
    page_size = get_last_page(browser, 'bidded_rejected')
    scrap_listing(gcp_sa, browser, page_size, start, '1QMa3CulWT4-gsTgy7fLsYlFzP_-cCalbggrAki4pBC0')
    print("biddded rejected Done")

def bidded_pending_acceptance(browser, gcp_sa):
    start = time()
    sleep(10)
    # Click Inventory Management dropdown
    reload_page_if_timeout(browser, '//*[@id="page-side-nav"]/ul/li[2]/ul/li[2]')
    browser.locator('//*[@id="page-side-nav"]/ul/li[2]/ul/li[2]').click()

    # Click Auctions module
    reload_page_if_timeout(browser, '//*[@id="inventory_management$Menu"]/li[3]')
    browser.locator('//*[@id="inventory_management$Menu"]/li[3]').click()
    # Click Ended Tab
    reload_page_if_timeout(browser, 'xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[5]')
    browser.locator('xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[5]').click()
    sleep(10)
    print("Start bidded pending acceptance")
    # Get last page
    page_size = get_last_page(browser, 'bidded_pending_acceptance')
    scrap_listing(gcp_sa, browser, page_size, start, '1q3d-KHGFUQF2pY_2EFeO5fGFd17w3SCvmvisNT3dUSw')
    print("bidded pending acceptance done")
    bidded_rejected(browser, gcp_sa)

def bidded_accepted(browser, gcp_sa):
    start = time()
    sleep(10)
    # Click Inventory Management dropdown
    reload_page_if_timeout(browser, '//*[@id="page-side-nav"]/ul/li[2]/ul/li[2]')
    browser.locator('//*[@id="page-side-nav"]/ul/li[2]/ul/li[2]').click()

    # Click Auctions module
    reload_page_if_timeout(browser, '//*[@id="inventory_management$Menu"]/li[3]')
    browser.locator('//*[@id="inventory_management$Menu"]/li[3]').click()

    # Click Accepted Tab
    reload_page_if_timeout(browser, 'xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[6]')
    browser.locator('xpath=//*[@id="__next"]/section/section/main/div/div[2]/div[3]/div[1]/div/div/div/div/div[1]/div[6]').click()
    sleep(5)
    print("Start bidded_accepted")
    # Get last page
    page_size = get_last_page(browser, 'bidded_accepted')
    scrap_listing(gcp_sa, browser, page_size, start, '1Ona-sPfAEnNe3p1PQBmP39g5S6aPo0XxT6Jx-2stWSE')
    print("bidded_accepted Done")
    bidded_pending_acceptance(browser, gcp_sa)
