from time import sleep, time
from utility import filter_date, get_last_page, scrap_listing
from threading import Event

def purchase_crawler_completed(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=305&type=x2b&groupViewId=x2b&viewId=completed&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start x2b completed")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_completed')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '126lP05nN9FtjGq7JgtgG_jdU861NSejLrvTSBOaoWUU')
    print("x2b completed Done")

def purchase_crawler_delivered(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=304&type=x2b&groupViewId=x2b&viewId=delivered&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start x2b delivered")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_delivered')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1-U3Ol4_b4LnHmbiv2UJdptCfpvkWMu9-4OV76GphNFU')
    print("x2b delivered Done")
    purchase_crawler_completed(browser, gcp_sa)

def purchase_crawler_partially_completed(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=528&type=x2b&groupViewId=x2b&viewId=transaction-partially-completed&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start x2b partially completed")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_partially_completed')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '16u1jzJt__y56A63rVPBv16uvNn88nr8NGkxrf9Yfo9o')
    print("x2b partially completed Done")
    purchase_crawler_delivered(browser, gcp_sa)

def purchase_crawler_paid(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=303&type=x2b&groupViewId=x2b&viewId=paid&filterDate=')
    sleep(10)
    print("Start x2b paid")
    #get last page
    page_size = get_last_page(browser, 'purchase_crawler_paid')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '18P6kOTrPzbFJIjLFs0vp6J51SVh9FI-GqUS_Y3Kj53c')
    print("x2b paid Done")
    purchase_crawler_partially_completed(browser, gcp_sa)

def purchase_crawler_car_in(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=301&type=x2b&groupViewId=x2b&viewId=car-in&filterDate=')
    sleep(10)
    print("Start x2b car-in")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_car_in')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1NwL0qB2O2Bl4vT9PjSdWTsdmdh0CAfFM-PT5YOyWF_U')
    print("x2b car-in Done")
    purchase_crawler_paid(browser, gcp_sa)

def x2b_purchase_crawler(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=300&type=x2b&groupViewId=x2b&viewId=processing&filterDate=')
    sleep(10)
    print("Start x2b purchase processing")
    # Get last page
    page_size = get_last_page(browser, 'x2b_purchase_crawler')
    # Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1GSoPKq2dzem5fufOZn636ZdCIZCwMpQjyWw5TryqD1A')
    print("x2b purchase processing Done")
    purchase_crawler_car_in(browser, gcp_sa)
