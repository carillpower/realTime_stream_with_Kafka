from time import sleep, time
from threading import Event
from utility import filter_date, get_last_page, scrap_listing

def all_transactions(browser, gcp_sa):
    start = time()
    sleep(10)
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&filterDate=&groupViewId=my-all-transactions&viewId=my-all-transactions')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[10]')
    print("Start Crawling All transactions")
    # Get last page
    page_size = get_last_page(browser, 'all_transactions')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1Gj6bQvnwOfuHPPyI1UyJxivBygB8Cr0SjseE7s8BRWM')
    print("All transactions Done")
