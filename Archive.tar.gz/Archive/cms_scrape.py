from time import sleep
# from auction_crawler_bidded_accepted import bidded_accepted
from auction_crawler_bidded_accepted import bidded_pending_acceptance
from mytukar_b2c_purchase import b2c_purchase
from x2b_purchase_crawler import x2b_purchase_crawler
from buy_in_purchase_crawler import buy_in_purchase_crawler
from all_transactions import all_transactions
from utility import slack_notification

def cms(browser, gcp_sa, scenario):
    print(scenario)
    scrape = ""
    try:
        if scenario == 'auction':
            # bidded_accepted(browser, gcp_sa)
            bidded_pending_acceptance(browser, gcp_sa)
            scrape = 'bidded_accepted'
            print("Auction data done... Sleeping")
        elif scenario == 'sales':
            b2c_purchase(browser, gcp_sa)
            scrape = 'b2c_purchase'
            print("B2C purchase data done... Sleeping")
            sleep(10)
            x2b_purchase_crawler(browser, gcp_sa)
            scrape = 'x2b_purchase_crawler'
            print("X2B purchase data done... Sleeping")
            sleep(10)
            buy_in_purchase_crawler(browser, gcp_sa)
            scrape = 'buy_in_purchase_crawler'
            print("Buy in purchase data done...")
            sleep(10)
            all_transactions(browser, gcp_sa)
            scrape = 'all_transactions'
            print("All Transactions data done...")
    except Exception as error:
        print(error)
        slack_notification(error, scrape)
    print("All DONE")
