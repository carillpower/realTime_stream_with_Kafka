from time import sleep, time
from threading import Event
from utility import filter_date, get_last_page, scrap_listing

def purchase_crawler_completed(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=305&type=buy&groupViewId=buy&viewId=completed&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start buy-in completed")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_completed')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1ESAQHB5BzAWE1BDdFNThsR3WxPAnY9oWZTssCQ47PSg')
    print("buy-in Done")

def purchase_crawler_partially_completed(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=528&type=buy&groupViewId=buy&viewId=transaction-partially-completed&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start Crawling buy-in partially completed")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_partially_completed')

    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '16cShXPiWJQRN0xLIFTcuCJ68cL42m5NKyafsJhtWpjo')
    print("buy-in partially completed Done")
    purchase_crawler_completed(browser, gcp_sa)

def purchase_crawler_paid(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=303&type=buy&groupViewId=buy&viewId=paid&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start buy-in paid")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_paid')

    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '17hQatHWYH5WYdnyC5VFFHraLmbS8e1HHB5ND_NOkTNA')
    print("buy-in paid Done")
    purchase_crawler_partially_completed(browser, gcp_sa)

def purchase_crawler_car_in(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=301&type=buy&groupViewId=buy&viewId=car-in&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start buy-in car-in")
    # Get last page
    page_size = get_last_page(browser, 'purchase_crawler_car_in')
    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1rmvsPK97HaP8DYKQUJMwB_lrwvpFgM0sOXe4WoFoPOQ')
    print("buy-in car-in Done")
    purchase_crawler_paid(browser, gcp_sa)

def buy_in_purchase_crawler(browser, gcp_sa):
    sleep(10)
    start = time()
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=300&type=buy&groupViewId=buy&viewId=processing&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start buy-in processing")
    # Get last page
    page_size = get_last_page(browser, 'buy_in_purchase_crawler')

    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '1k5TOI_OwH-MOsTxef2U9tTtaK3u7Mx73AxMKhMS5e8c')
    print("buy-in processing Done")
    purchase_crawler_car_in(browser, gcp_sa)
