
google-api-python-client
google-auth-httplib2
google-auth-oauthlib
playwright==1.25.2
selenium==4.15.0
pandas==1.3.4
beautifulsoup4==4.11.2
gspread==5.3.0
slack-sdk==3.8.0
