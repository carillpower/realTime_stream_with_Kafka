from time import sleep, time
import random
from datetime import date, datetime
from slack_sdk.webhook import WebhookClient
from bs4 import BeautifulSoup
import pandas as pd

def slack_notification(msg, module):
    message = []
    developer = "@channel"
    slack_webhook_url = (
    'https://hooks.slack.com/services/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'
    )
    message.append(f"FYI {developer} \n Please Acknowledge {module} {str(msg)}")
    slack_client = WebhookClient(slack_webhook_url)
    slack_client.send(
        text="fallback",
        blocks=[
            {"type": "section", "text": {"type": "mrkdwn", "text": msg}}
            for msg in message
        ],
    )

def reload_page_if_timeout(browser, selector):
    max_retries = 3
    e = ""
    for _ in range(max_retries):
        try:
            browser.wait_for_selector(selector)
            return
        except Exception as error:
            print("retrying")
            browser.reload()
            sleep(10)
            e = error
    raise Exception(e)

def filter_date(browser, selector):
    # Click Agreement button
    # '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]'
    reload_page_if_timeout(browser, selector)
    browser.locator(selector).click()

    # Filter Start Date
    reload_page_if_timeout(browser, '.ant-calendar-picker')
    browser.query_selector('.ant-calendar-picker').click()

    reload_page_if_timeout(browser, '.ant-calendar-input-wrap')
    calendar = browser.query_selector('.ant-calendar-input-wrap')

    first_day_of_month = datetime.today().replace(day=1)
    calendar.query_selector('.ant-calendar-input ').fill(str(first_day_of_month.date()))
    sleep(3)
    reload_page_if_timeout(browser, '.ant-calendar-body')
    calendar_date = browser.query_selector('.ant-calendar-body')
    # Click end date
    today = date.today().strftime("%B %d, %Y").lstrip("0").replace(" 0", " ").lstrip("0").replace(" 0", " ")
    print(f"Today = {today}")
    sleep(3)
    calendar_date.query_selector(f'[title="{today}"]').click()
    print("Setting Calendar Date Done")
    sleep(10)

def get_last_page(browser, module):
    page_size = 0
    try:
        browser.wait_for_selector('div[class="ant-list-pagination"]')
        page_pagination = BeautifulSoup(browser.query_selector('div[class="ant-list-pagination"]').inner_html(),features='html.parser')
        page_size = page_pagination.find('ul', class_='ant-pagination').find_all('li')[-2].text
    except Exception:
        print(f"No car {module} listing")
    
    return int(page_size)

def scrap_listing(gcp_sa, browser, page_size, start, gsheet_id):
    # setting default last page bcuz there will be possiblity of empty listing when on a new month
    last_page = 0
    current_page = 1
    all_page_table_data = []

    if page_size > last_page:
        print(page_size)
        for current_page_size in range(current_page,int(page_size)+1):
            print("page: ", current_page_size)
            reload_page_if_timeout(browser, '.ant-list-items')
            page_body = browser.query_selector('.ant-list-items')
            row_item = page_body.query_selector_all('.ant-row-flex')
            for i in row_item:
                d = {}
                html = BeautifulSoup(i.inner_html(),features='html.parser')
                d['lead_id'] = html.find('div', class_='text-label').text
                d['title'] = html.find('div', class_='title-value has-text-weight-bold').text
                d['schedule_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                all_columns_box = i.query_selector_all('.ant-col ')
                for j in all_columns_box[1:]:
                    d[j.query_selector('.text-label').text_content()] = j.query_selector('.text-value').text_content()
                all_page_table_data.append(d)

            reload_page_if_timeout(browser, ".ant-pagination-item-active")
            current_active_page_number = browser.query_selector(".ant-pagination-item-active").query_selector("a").text_content()
            print("*******************************************")
            print("Done for current page:" ,current_page_size)

            ## Grabbing Next Button
            print("Clicking next page...going to next page...")
            reload_page_if_timeout(browser, ".ant-list-pagination")
            browser.query_selector('.ant-list-pagination').query_selector('[title="Next Page"]').click()
            sleep(1) # MUST WAIT 1 second after clicking next

            # Ensure reached next page
            while current_page_size == current_active_page_number:
                print("On the way to next page: ",current_active_page_number, "...loading...")

            # Reached next page! start waiting!**current_active_page_number + 1**
            print("Done going to next page..", "Current Page: ", current_active_page_number, "....and act waiting")
            print("*******************************************")
            sleep(random.randint(3, 5)) # Wait 3 to 5 seconds

        print("Done Crawling for all data! Total Page: ", page_size)
        print("Total Crawled Row Data", len(all_page_table_data))

        # record end time
        end = time()

        # Total Execuration Duration
        print("The time of execution of above program is :",   round((end-start)/60,2), "minutes...")

        all_page_table_df = pd.DataFrame(all_page_table_data)
        all_page_table_df = all_page_table_df.astype(str)
        # all_page_table_df.to_csv('b2c_purchase.csv', index=False)
        # workbook = gcp_sa.open_by_key('104bYV9UFU5IeuMwA6ZBkjQ1a3xprDntarOWRKaDJB_0')
        workbook = gcp_sa.open_by_key(gsheet_id)
        worksheets = workbook.worksheets()
        worktab = workbook.worksheet(worksheets[0].title)
        if len(worktab.get_all_values()) < 1:
            worktab.update([all_page_table_df.columns.values.tolist()])
            worktab.append_rows(all_page_table_df.values.tolist())
        else:
            worktab.append_rows(all_page_table_df.values.tolist())
