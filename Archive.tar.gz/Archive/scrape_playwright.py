from playwright.sync_api import sync_playwright
from time import sleep, time
from cms_scrape import cms
from threading import Event
from oauth2client.service_account import ServiceAccountCredentials
import os
import json
import gspread
import argparse

os.environ["DISPLAY"]=':1'

class LoginCredential():
    def __init__(self, username, password):
        self.user = username
        self.security = password

    @property
    def username(self):
        return self.user

    @property
    def password(self):
        return self.security

class Browser():
    def __init__(self, playwright, credentials):
        start_url = "https://captain.carro.sg/login?redirectUrl=%2F"
        self.chromium = playwright.chromium
        self.driver = self.chromium.launch(headless=False).new_page()
        self.driver.goto(start_url)
        self.credential = credentials
        self.scope = ["https://spreadsheets.google.com/feeds",
                    "https://www.googleapis.com/auth/drive"]
        # /app/Archieve/
        with open('/Users/nixon.tan/hello/scraping-403803-209a956945c3.json', 'r') as self.file:
            self.gsheet_secret = json.loads(self.file.read())
        self.gcp_credentials = ServiceAccountCredentials.from_json_keyfile_dict(self.gsheet_secret, self.scope)
        self.gc = gspread.authorize(self.gcp_credentials)
    
    # def set_gsheet_by_key(self, spreadsheet_id):
    #     self.wb = self.gc.open_by_key(spreadsheet_id)

    # def get_all_worksheets(self):
    #     if self.wb is None:
    #         raise ValueError("please choose a gsheet file!")
    #     return self.wb.worksheets()

    # def identify_worksheet_by_title(self, name):
    #     if self.wb is None:
    #         raise ValueError("please choose a gsheet file!")
    #     return self.wb.worksheet(name)

    # def get_worksheet_by_title(self, name):
    #     if self.wb is None:
    #         raise ValueError("please choose a gsheet file!")
    #     return self.wb.worksheet(name).get_all_values()

    def login_auction_system(self):
        self.driver.locator('xpath=//*[@id="email"]').fill(self.credential.username)
        self.driver.locator('xpath=//*[@id="password"]').fill(self.credential.password)
        sleep(1)
        self.driver.locator('xpath=//*[@id="__next"]/div/div[2]/div/div/form/div[2]/button').click()
        # self.driver.pause()
        # Event().wait()

    def crawl(self, scenario):
        cms(self.driver, self.gc, scenario)

    # def retail_sales(self):
    #     b2c_retail_sales_delivered(self.driver)

    # def purchase(self):
    #     b2c_purchase(self.driver, self.gc)

    # def x2b_purchase_crawl(self):
    #     x2b_purchase_crawler(self.driver)

    # def buy_in_purchase_crawl(self):
    #     buy_in_purchase_crawler(self.driver)

    # def odo(self):
    #     all_transactions(self.driver, self.gc)

def main(p, lc, scenario):
    browser = Browser(p, lc)
    browser.login_auction_system()
    browser.crawl(scenario)

if __name__ == '__main__':
    start = time()
    parser = argparse.ArgumentParser()
    parser.add_argument('--scenario',
                        required=True,
                        help='Module to scrape')
    args = parser.parse_args()
    scenario = args.scenario
    with sync_playwright() as p:
        lc = LoginCredential(username='nuralbaniah.ghazali@mytukar.com', password='nuralbaniah92')
        main(p, lc, scenario)
    end = time()
    print("Total execution time is :",   round((end-start)/60,2), "minutes...")
