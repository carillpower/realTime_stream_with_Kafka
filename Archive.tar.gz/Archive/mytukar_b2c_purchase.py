from time import sleep, time
from threading import Event
from utility import filter_date, get_last_page, scrap_listing

def b2c_retail_sales_completed(browser, gcp_sa):
    start = time()
    sleep(10)
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=305&type=sell&groupViewId=sell&viewId=completed&filterDate=')
    sleep(10)
    print("Start b2c_retail_sales_completed")
    # Get last page
    page_size = get_last_page(browser, 'b2c_retail_sales_completed')
    # Event().wait()
    scrap_listing(gcp_sa, browser, page_size, start, '1UjXKDfw2Qi12CwsYa665gDv-qTLqeVFtuX8FhvMQOrw')
    print("b2c_retail_sales_completed Done")

def b2c_retail_sales_delivered(browser, gcp_sa):
    start = time()
    sleep(10)
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=304&type=sell&groupViewId=sell&viewId=delivered&filterDate=')
    sleep(10)
    filter_date(browser, '//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start Crawling for b2c_retail_sales_delivered")
    # Get last page
    page_size = get_last_page(browser, 'b2c_retail_sales_delivered')

    ## Start Data Crawling
    scrap_listing(gcp_sa, browser, page_size, start, '11XVDhdfiNnmWrouQNeGooTK64lupX8rPWtuvTR6J2vc')
    print("Start b2c_retail_sales_delivered Done")
    b2c_retail_sales_completed(browser, gcp_sa)

def b2c_purchase(browser, gcp_sa):
    sleep(10)
    browser.goto('https://captain.carro.sg/transactions?page=1&sort=-created_at&status%3Aid=305&type=sell_wholesale&groupViewId=sell-wholesale&viewId=completed&filterDate=')
    sleep(10)
    start = time()

    #Filtering scraping date with calendar date
    filter_date(browser,'//*[@id="__next"]/section/section/main/div/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/button[9]')
    print("Start b2c purchase completed")
    # Get last page
    page_size = get_last_page(browser, 'b2c_purchase')

    scrap_listing(gcp_sa, browser, page_size, start, '104bYV9UFU5IeuMwA6ZBkjQ1a3xprDntarOWRKaDJB_0')
    print("b2c purchase completed Done")
    b2c_retail_sales_delivered(browser, gcp_sa)
