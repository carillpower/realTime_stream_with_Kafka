
from flask import Flask, render_template, Response   

from pykafka import KafkaClient as kc  

def get_kafka_client():
    return kc(hosts='172.20.186.93:9092')

consumer = Flask(__name__)   

@consumer.route('/')
def index():
    return( render_template('index.html') )

@consumer.route('/topic/<topic_name>') 
def get_message(topic_name):
    client = get_kafka_client()
    def events():
        for i in client.topics[topic_name].get_simple_consumer(): 
            yield 'data:{0}\n\n'.format( i.value.decode() ) 

    return Response( events() , mimetype='text/event-stream')  


if __name__ == '__main__':
    consumer.run(debug=True, port=15001)  

