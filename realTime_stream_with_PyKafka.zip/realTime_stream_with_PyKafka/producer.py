
'''
This will stream the data 

## Howto Run:
# python producer.py 1 &
# python producer.py 2 &
# python producer.py 3 &

## Test, if open other session for consumer for this topic should see the result
## $KAFKA_HOME/bin/kafka-console-consumer.sh --bootstrap-server 172.20.186.93:9092 --topic topic_shahril_realtime --from-beginning

'''
from pykafka import KafkaClient as kc  
import json  
from datetime import datetime as dt  
import uuid     
import sys      
import time     

client = kc( hosts='172.20.186.93:9092')  
topic = client.topics[b'topic_shahril_realtime']   ## Define topic related

producer = topic.get_sync_producer()


input_file = open('./data/route.json')
'''Result: <_io.TextIOWrapper name='./data/route.json' mode='r' encoding='UTF-8'>'''

json_array = json.load(input_file)
coordinates = json_array['features'][0]['geometry']['coordinates']  ## This variable for lat/long

sess = str('0000'+ sys.argv[1] )

def generate_uuid():
    return uuid.uuid4()

data = {}  

def generate_checkpoint(coordinates):
    i = 0
    while i < len(coordinates):     ## Loop until total count of rows
        data['run_checkpoint'] = sess
        data['key_uuid'] = data['run_checkpoint'] + '_' + str(generate_uuid())
        data['timestamp'] = str( dt.utcnow() )
        data['latitude'] = coordinates[i][1]
        data['longitude'] = coordinates[i][0]
        msg = json.dumps(data)  ## store data into msg
        #print(msg)
        '''
        Result:
        {"run_checkpoint": "00001", "key_uuid": "00001_1300a6c8-da88-46b7-86fd-7528a16ce5e9", "timestamp": "2020-10-27 09:02:41.384405", "latitude": 6.129076666475932, "longitude": 100.34886360168456}
        {"run_checkpoint": "00001", "key_uuid": "00001_19662a7e-1239-4a86-9df4-b53388a249dd", "timestamp": "2020-10-27 09:02:41.384487", "latitude": 6.126943160442978, "longitude": 100.35319805145264}
        {"run_checkpoint": "00001", "key_uuid": "00001_b1db3dbc-7e27-431f-898a-44e3cd686967", "timestamp": "2020-10-27 09:02:41.384529", "latitude": 6.1254070308185256, "longitude": 100.35714626312256}
        {"run_checkpoint": "00001", "key_uuid": "00001_87a35def-b68d-444c-bba9-ee4a833bf8d1", "timestamp": "2020-10-27 09:02:41.384562", "latitude": 6.123998908113393, "longitude": 100.36053657531738}
        {"run_checkpoint": "00001", "key_uuid": "00001_12670474-0afa-4767-9712-e37fd6dcdd19", "timestamp": "2020-10-27 09:02:41.384592", "latitude": 6.121267992890521, "longitude": 100.35512924194336}
        {"run_checkpoint": "00001", "key_uuid": "00001_6977d738-c5dd-4822-bc5a-36b11976a8b6", "timestamp": "2020-10-27 09:02:41.384620", "latitude": 6.124169589851178, "longitude": 100.35105228424072}
        {"run_checkpoint": "00001", "key_uuid": "00001_b9faa841-d087-46a1-8c0b-92eafdfe67b0", "timestamp": "2020-10-27 09:02:41.384647", "latitude": 6.126004415086635, "longitude": 100.34718990325926}
        {"run_checkpoint": "00001", "key_uuid": "00001_6a9399a7-3626-497b-b883-b33900b69730", "timestamp": "2020-10-27 09:02:41.384682", "latitude": 6.129759386604883, "longitude": 100.34555912017821}
        {"run_checkpoint": "00001", "key_uuid": "00001_00c734df-db1a-4cc1-b4fd-714e96361264", "timestamp": "2020-10-27 09:02:41.384723", "latitude": 6.1305274457056536, "longitude": 100.34791946411133}
        '''   

        producer.produce( msg.encode('ascii'))     
        time.sleep(1)   

        if i == len(coordinates)-1:
            i = 0
        else:
            i += 1
        


generate_checkpoint(coordinates)    




